public class Recommendation {

    public static double similarity(int[] a, int[] b) {
        int dot = 0, aSum = 0, bSum = 0;
        for (int i = 0; i < a.length; i++) {
            dot += a[i] * b[i];
            aSum += a[i] * a[i];
            bSum += b[i] * b[i];
        }
        return dot / (Math.sqrt(aSum) * Math.sqrt(bSum));
    }

    public static void main(String[] args) {
        int[][] ratings = {
            {5, 3, 0},  
            {4, 0, 2},  
            {0, 4, 5}   
        };

        String[] movies = {"Movie1", "Movie2", "Movie3"};

        double simAB = similarity(ratings[0], ratings[1]);
        double simAC = similarity(ratings[0], ratings[2]);

        int recommendedIndex = simAB > simAC ? 1 : 2;

        System.out.println("Best Recommendation for User A: " + movies[recommendedIndex]);
    }
}
