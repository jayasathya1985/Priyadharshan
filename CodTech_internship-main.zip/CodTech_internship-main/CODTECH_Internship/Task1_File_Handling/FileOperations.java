import java.io.*;

public class FileOperations {
    public static void main(String[] args) {
        String filename = "sample.txt";

        try {
             FileWriter writer = new FileWriter(filename);
            writer.write("CODTECH Internship - Task 1\n");
            writer.write("This is a sample file.\n");
            writer.close();

            BufferedReader reader = new BufferedReader(new FileReader(filename));
            String line;
            System.out.println("----- FILE CONTENT -----");
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
            reader.close();

            FileWriter modifier = new FileWriter(filename, true);
            modifier.write("Modified: New line added.\n");
            modifier.close();

            BufferedReader countReader = new BufferedReader(new FileReader(filename));
            int count = 0;
            while (countReader.readLine() != null) count++;
            countReader.close();

            System.out.println("Total Lines in File: " + count);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
