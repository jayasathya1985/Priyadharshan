import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;

public class ApiClient {
    public static void main(String[] args) {
        try {
            URL url = new URL("https://fakestoreapi.com/products");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(conn.getInputStream())
            );

            String line;
            StringBuilder response = new StringBuilder();

            while ((line = in.readLine()) != null) {
                response.append(line);
            }
            in.close();

            JSONArray arr = new JSONArray(response.toString());

            System.out.println("\n=========== PRODUCT LIST ===========");
            for (int i = 0; i < 5; i++) {  
                JSONObject obj = arr.getJSONObject(i);
                System.out.println("\nProduct #" + (i + 1));
                System.out.println("Title    : " + obj.getString("title"));
                System.out.println("Price    : $" + obj.getDouble("price"));
                System.out.println("Category : " + obj.getString("category"));
                
                JSONObject rating = obj.getJSONObject("rating");
                System.out.println("Rating   : " + rating.getDouble("rate") + "/5");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
